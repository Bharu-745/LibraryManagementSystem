package com.example.lms.LlbraryManagementSystem.dao;

import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.Repository;

import com.example.lms.LlbraryManagementSystem.model.User;



	public interface UserDetailsDAO extends Repository <User,String>{
		User findByUsernameAndPassword(String Name, String Password);
		

		}
