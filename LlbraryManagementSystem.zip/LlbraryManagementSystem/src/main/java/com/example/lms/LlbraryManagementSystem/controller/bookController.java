package com.example.lms.LlbraryManagementSystem.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.example.lms.LlbraryManagementSystem.dao.BookDAO;
import com.example.lms.LlbraryManagementSystem.dao.BookDetailsDAO;
import com.example.lms.LlbraryManagementSystem.dao.UserDetailsDAO;
import com.example.lms.LlbraryManagementSystem.model.Boo;
import com.example.lms.LlbraryManagementSystem.model.User;
import com.example.lms.LlbraryManagementSystem.model.SaveBook;

@Controller
public class bookController {
	
	@Autowired
	BookDAO bdao;
	@Autowired
	BookDetailsDAO bddao;
	@Autowired
	UserDetailsDAO udao;
	
	@RequestMapping("/home")
	public String Home() {
		return "home";
	}
	
	
	
	
	@RequestMapping("addBook")
	public String addBookmethod(Boo b)
	{
		bdao.save(b);
		return "adminhome";
	}
	
	@RequestMapping("adminLogin")
	public String adminLogin()
	{
		return "adminLogin";
	}
	
	@RequestMapping("adminhome")
	public ModelAndView adminhomemethod(@RequestParam String name, @RequestParam String pwd) 
	{
		User user = udao.findByUsernameAndPassword(name, pwd);
		
		try 
		{
		if(pwd.equals(user.getPassword()) && name.equals(user.getUserName())) {
			System.out.println("Inside If Block");
			ModelAndView mav = new ModelAndView("adminhome");
			
			mav.addObject("msg", user);	
			return mav;
		}
		else {
			System.out.println("Inside Else Block");
			ModelAndView mav = new ModelAndView("home");
			mav.addObject("notAdminerror", "Admin Authentication Failed");
			return mav;
		}
		}
		catch(Exception e) {
			System.out.println("Inside Catch Block");
			ModelAndView mav = new ModelAndView("home");
			mav.addObject("notAdminerror", "Admin Authentication Failed");
			return mav;
			
		}
		
	}
	

	@RequestMapping("getBook")
	public ModelAndView getBookmethod(@RequestParam int id) 
	{
		ModelAndView mav = new ModelAndView("book");
		Boo b = bdao.findById(id).orElse(new Boo());
		mav.addObject("msg", b);
		System.out.println("----------------");
		System.out.println("Id is"+id);
		System.out.println(bdao.findById(id).orElse(new Boo()));
		System.out.println("B is :"+b);
		System.out.println(mav);
		System.out.println("----------------");
		return mav;
	}
	
	
	
	@RequestMapping("getBookName")
	public ModelAndView getBookNamemethod(@RequestParam String name) 
	{
		ModelAndView mav = new ModelAndView("book");
		Boo b = bddao.findByName(name);
		mav.addObject("msg", b);
		System.out.println("----------------");
		System.out.println("Name is"+name);
		System.out.println(bddao.findByName(name));
		System.out.println("B is :"+b);
		System.out.println(mav);
		System.out.println("----------------");
		return mav;
	}
	
	@RequestMapping("getBookAuthor")
	public ModelAndView getBookAuthormethod(@RequestParam String author) 
	{
		ModelAndView mav = new ModelAndView("book");
		Boo b = bddao.findByAuthor(author);
		mav.addObject("msg", b);
		System.out.println("----------------");
		System.out.println("Name is"+author);
		System.out.println(bddao.findByAuthor(author));
		System.out.println("B is :"+b);
		System.out.println(mav);
		System.out.println("----------------");
		return mav;
	}
	
	@RequestMapping("getBookPublisher")
	public ModelAndView getBookPubmethod(@RequestParam String pub) 
	{
		ModelAndView mav = new ModelAndView("book");
		Boo b = bddao.findByPublisher(pub);
		mav.addObject("msg", b);
		System.out.println("----------------");
		System.out.println("Name is"+pub);
		System.out.println(bddao.findByPublisher(pub));
		System.out.println("B is :"+b);
		System.out.println(mav);
		System.out.println("----------------");
		return mav;
	}
	
	@RequestMapping("deleteBook")
	public ModelAndView deleteBookmethod(@RequestParam int id) 
	{
		ModelAndView mav = new ModelAndView("deletebook");
		Boo b = bdao.findById(id).orElse(new Boo());
		mav.addObject("msg", b);
		System.out.println("----------------");
		System.out.println("Id is"+id);
		bdao.deleteById(id);
		System.out.println("B is :"+b);
		System.out.println(mav);
		System.out.println("----------------");
		return mav;
	}
	
	@RequestMapping("updateBook")
	public ModelAndView updateBookmethod(Boo b) 
	{
		ModelAndView mav = new ModelAndView("updatebook");
		b = bdao.findById(b.getId()).orElse(new Boo());
		mav.addObject("bookid", b.getId());
		mav.addObject("bookname", b.Name());
		mav.addObject("bookauthor", b.getAuthor());
		mav.addObject("bookpub", b.getPublisher());
		System.out.println("----------------");
		System.out.println("Id is"+b.getId());
		bdao.deleteById(b.getId());
		System.out.println("B is :"+b);
		System.out.println(mav);
		System.out.println("----------------");
		return mav;
	}
}