package com.example.lms.LlbraryManagementSystem.dao;

import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.Repository;

import com.example.lms.LlbraryManagementSystem.model.Boo;



	public interface BookDetailsDAO extends Repository <Boo,String>{
		Boo findByName(String Name);
		Boo findByAuthor(String Author);
		Boo findByPublisher(String Publisher);

		}
