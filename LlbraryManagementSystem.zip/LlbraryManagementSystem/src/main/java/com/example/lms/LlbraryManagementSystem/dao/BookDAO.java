package com.example.lms.LlbraryManagementSystem.dao;

import org.springframework.data.repository.CrudRepository;

import com.example.lms.LlbraryManagementSystem.model.Boo;



	public interface BookDAO extends CrudRepository <Boo,Integer>{

		}
