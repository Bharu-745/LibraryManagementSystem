package com.example.lms.LlbraryManagementSystem.model;

public class SaveBook {

}
