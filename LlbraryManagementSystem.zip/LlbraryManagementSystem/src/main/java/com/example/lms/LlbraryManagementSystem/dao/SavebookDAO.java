package com.example.lms.LlbraryManagementSystem.dao;

import org.springframework.data.repository.CrudRepository;

import com.example.lms.LlbraryManagementSystem.model.SaveBook;

public interface SavebookDAO extends CrudRepository <SaveBook,Integer> {

}
