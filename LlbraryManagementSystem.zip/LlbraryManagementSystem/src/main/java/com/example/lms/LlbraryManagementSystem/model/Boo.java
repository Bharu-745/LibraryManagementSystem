package com.example.lms.LlbraryManagementSystem.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
public class Boo {
	@Id
	private int id;
	
	private String name;	
	private String publisher;	
	private String author;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String Name() {
		return name;
	}
	public void setName(String bname) {
		name = bname;
	}
	public String getPublisher() {
		return publisher;
	}
	public void setPublisher(String publish) {
		publisher = publish;
	}
	public String getAuthor() {
		return author;
	}
	public void setAuthor(String auth) {
		author = auth;
	}
	
	@Override
	public String toString() {
		return "id=" + id + ","+"<br>"+"Name=" + name+ ","+"<br>"+ "Publisher=" + publisher+ ","+"<br>" + "Author=" + author;
	}

}
